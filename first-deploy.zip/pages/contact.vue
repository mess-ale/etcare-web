<template>
    <div>
        <serviceCard text="Contact Us" imgservice="/2.jpg" />
        <div class="">
            <div class="body-padding_margin">
                <div class="container">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="space-y-8 mb-10">
                            <div class="space-y-2">
                                <h1 class="font-oswald xxxs:text-3xl md:text-3xl font-bold text-secondary">ADDRESS</h1>
                                <div class="flex items-center space-x-4 text-secondary font-robot">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em"
                                        viewBox="0 0 24 24">
                                        <path fill="currentColor"
                                            d="M12 12q.825 0 1.413-.587T14 10t-.587-1.412T12 8t-1.412.588T10 10t.588 1.413T12 12m0 10q-4.025-3.425-6.012-6.362T4 10.2q0-3.75 2.413-5.975T12 2t5.588 2.225T20 10.2q0 2.5-1.987 5.438T12 22">
                                        </path>
                                    </svg>
                                    <p class="text-primary">head office 22 mazoria ,Golagol</p>
                                </div>
                                <div class="flex items-center space-x-4 text-secondary font-oswald">

                                    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em"
                                        viewBox="0 0 24 24">
                                        <path fill="currentColor"
                                            d="M19.95 21q-3.125 0-6.175-1.362t-5.55-3.863t-3.862-5.55T3 4.05q0-.45.3-.75t.75-.3H8.1q.35 0 .625.238t.325.562l.65 3.5q.05.4-.025.675T9.4 8.45L6.975 10.9q.5.925 1.187 1.787t1.513 1.663q.775.775 1.625 1.438T13.1 17l2.35-2.35q.225-.225.588-.337t.712-.063l3.45.7q.35.1.575.363T21 15.9v4.05q0 .45-.3.75t-.75.3">
                                        </path>
                                    </svg>
                                    <p class="text-primary">+251-96-454-0000</p>
                                </div>
                                <div class="flex items-center space-x-4 text-secondary font-robot">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em"
                                        viewBox="0 0 24 24">
                                        <path fill="currentColor"
                                            d="M4 20q-.825 0-1.412-.587T2 18V6q0-.825.588-1.412T4 4h16q.825 0 1.413.588T22 6v12q0 .825-.587 1.413T20 20zm8-7L4 8v10h16V8zm0-2l8-5H4zM4 8V6v12z">
                                        </path>
                                    </svg>
                                    <p class="text-primary">saccosetcare@gmail.com</p>
                                </div>
                            </div>

                            <div class="space-y-2">
                                <h1 class="font-oswald  xxxs:text-3xl md:text-3xl  font-bold text-secondary">WORKING
                                    HOURS</h1>
                                <div class="flex items-center space-x-4 text-secondary font-robot">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em"
                                        viewBox="0 0 24 24">
                                        <path fill="currentColor"
                                            d="M8 14q.425 0 .713-.288T9 13t-.288-.712T8 12t-.712.288T7 13t.288.713T8 14m4 0q.425 0 .713-.288T13 13t-.288-.712T12 12t-.712.288T11 13t.288.713T12 14m4 0q.425 0 .713-.288T17 13t-.288-.712T16 12t-.712.288T15 13t.288.713T16 14m-4 8q-1.875 0-3.512-.712t-2.85-1.925t-1.925-2.85T3 13t.713-3.512t1.924-2.85t2.85-1.925T12 4t3.513.713t2.85 1.925t1.925 2.85T21 13t-.712 3.513t-1.925 2.85t-2.85 1.925T12 22M5.6 2.35L7 3.75L2.75 8l-1.4-1.4zm12.8 0l4.25 4.25l-1.4 1.4L17 3.75zM12 20q2.925 0 4.963-2.037T19 13t-2.037-4.962T12 6T7.038 8.038T5 13t2.038 4.963T12 20">
                                        </path>
                                    </svg>
                                    <p class="text-primary">2:00 am to 11:00pm on Weekdays and saturday</p>
                                </div>
                            </div>

                            <div class="space-y-2">
                                <h1 class="font-oswald  xxxs:text-3xl md:text-3xl  font-bold text-secondary">FOLLOW US
                                </h1>
                                <div class="flex space-x-3">
                                    <nuxt-link to="https://web.facebook.com/etcaresacco" target="_blank"><svg
                                            class="socialM text-primary" xmlns="http://www.w3.org/2000/svg" width="2em"
                                            height="2em" viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95">
                                            </path>
                                        </svg></nuxt-link>
                                    <nuxt-link to="https://www.youtube.com/@etcarebeautyandcosmeticssales"
                                        target="_blank">
                                        <svg class="socialM text-primary" xmlns="http://www.w3.org/2000/svg" width="2em"
                                            height="2em" viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="M12.244 4c.534.003 1.87.016 3.29.073l.504.022c1.429.067 2.857.183 3.566.38c.945.266 1.687 1.04 1.938 2.022c.4 1.56.45 4.602.456 5.339l.001.152v.174c-.007.737-.057 3.78-.457 5.339c-.254.985-.997 1.76-1.938 2.022c-.709.197-2.137.313-3.566.38l-.504.023c-1.42.056-2.756.07-3.29.072l-.235.001h-.255c-1.13-.007-5.856-.058-7.36-.476c-.944-.266-1.687-1.04-1.938-2.022c-.4-1.56-.45-4.602-.456-5.339v-.326c.006-.737.056-3.78.456-5.339c.254-.985.997-1.76 1.939-2.021c1.503-.419 6.23-.47 7.36-.476zM9.999 8.5v7l6-3.5z">
                                            </path>
                                        </svg></nuxt-link>
                                    <nuxt-link to="https://vm.tiktok.com/ZMhQxWYC7/" target="_blank"> <svg
                                            class="socialM text-primary" xmlns="http://www.w3.org/2000/svg" width="2em"
                                            height="2em" viewBox="0 0 24 24">
                                            <path
                                                d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74a2.89 2.89 0 0 1 2.31-4.64a2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"
                                                fill="currentColor"></path>
                                        </svg></nuxt-link>

                                    <nuxt-link to="https://t.me/etcaresacco" target="_blank"><svg
                                            class="socialM text-primary" xmlns="http://www.w3.org/2000/svg" width="2em"
                                            height="2em" viewBox="0 0 24 24">
                                            <path
                                                d="M9.78 18.65l.28-4.23l7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3L3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z"
                                                fill="currentColor"></path>
                                        </svg></nuxt-link>
                                </div>
                            </div>
                        </div>
                        <div class="mb-10">
                            <iframe
                                class="google-map-etcare"
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d250.58637222636318!2d38.788502794348865!3d9.017772981720599!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x164b8536dfa41f0d%3A0x82c1ac4735b86c63!2sEtcare%20Beauty%20Products%20Sales%20P.l.c!5e0!3m2!1sen!2set!4v1730728562675!5m2!1sen!2set"
                                style="border:0;" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
useHead({
  title: 'Contact Us - Etcare SACCOs Ltd',
});
</script>

<style>
.google-map-etcare {
    width: 100%;
    min-height: 20rem;
    height: 100%;
}
</style>