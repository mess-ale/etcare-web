import{p as o}from"./dpUPDKye.js";const p=o("/logo1-removebg.png");export{p as _};
