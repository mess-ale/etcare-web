<template>
    <div class="text-primary pb-8">
        <ServiceCard text="Training" imgservice="/service/training.JPG" />
        <div class="body-padding_margin ">
            <div class="container">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div>
                        <div class="saving-right-box">
                            <!-- Section Header -->
                            <h1 class="text-primary font-oswald text-2xl text-center font-bold p-4">Why Save with Us?
                            </h1>

                            <!-- Feature List -->
                            <div class="space-y-2">
                                <!-- Feature Item -->
                                <div class="flex gap-4 p-4 border-b border-gray-200">
                                    <div class="flex flex-col items-center text-secondary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="3.5em" height="3.5em"
                                            viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="M12 19.9q2.425-.75 4.05-2.962T17.95 12H12V4.125l-6 2.25v5.175q0 .175.05.45H12zm0 2q-.175 0-.325-.025t-.3-.075Q8 20.675 6 17.638T4 11.1V6.375q0-.625.363-1.125t.937-.725l6-2.25q.35-.125.7-.125t.7.125l6 2.25q.575.225.938.725T20 6.375V11.1q0 3.5-2 6.538T12.625 21.8q-.15.05-.3.075T12 21.9">
                                            </path>
                                        </svg>
                                        <h2 class="text-lg font-bold mt-2">Security</h2>
                                    </div>
                                    <p class="text-primary items-center flex text-justify">
                                        Your savings are safe with us, backed by a trusted cooperative structure.
                                    </p>
                                </div>

                                <!-- Repeat for each feature -->
                                <div class="flex gap-4 p-4 border-b border-gray-200">
                                    <div class="flex flex-col items-center text-secondary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="3.5em" height="3.5em"
                                            viewBox="0 0 512 512">
                                            <path fill="currentColor"
                                                d="M144.938 18.063l8.437 19.187c17.36 39.43 27.86 79.965 32.563 120.313c-50.01 4.028-99.724 4.15-144.688 1.656l-21.188-1.19L33.5 174.438c42.232 51.6 93.612 82.498 148.438 110.907c-12.137 69.664-39.726 134.1-77.282 185.312L92 487.906l21.25-2.437c99.754-11.457 177.9-51.146 236.688-106.064c33.06 23.513 65.993 52.01 98.093 88.97l15.095 17.374l1.28-22.97c3.558-63.803-8.63-128.11-33.655-187.53c37.76-67.647 57.985-143.224 63.563-214.656l2-25.532l-17.97 18.22c-35.647 36.18-86.34 61.284-143.468 78.124c-46.935-47.74-104.638-85.32-170.03-106.812l-19.907-6.532z">
                                            </path>
                                        </svg>
                                        <h2 class="text-lg font-bold mt-2">Flexibility</h2>
                                    </div>
                                    <p class="text-primary text-justify">
                                        Choose from various saving plans that suit your needs.
                                    </p>
                                </div>

                                <div class="flex gap-4 p-4 border-b border-gray-200">
                                    <div class="flex flex-col items-center text-secondary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="3.5em" height="3.5em"
                                            viewBox="0 0 14 14">
                                            <path fill="currentColor" fillRule="evenodd"
                                                d="M10.326.28a.5.5 0 0 1 .506-.229l2.571.429a.5.5 0 0 1 .411.575l-.428 2.572a.5.5 0 0 1-.9.208l-.694-.97l-3.574 2.284a.75.75 0 0 1-.974-.144l-1.993-2.33L1.524 4.59a.75.75 0 1 1-.686-1.334l4.255-2.187a.75.75 0 0 1 .913.18L7.96 3.534l2.96-1.892l-.577-.807a.5.5 0 0 1-.017-.555">
                                            </path>
                                        </svg>
                                        <h2 class="text-lg font-bold mt-2">Growth</h2>
                                    </div>
                                    <p class="text-primary text-justify">
                                        Earn competitive interest rates on your savings, helping you grow your funds
                                        over
                                        time.
                                    </p>
                                </div>

                                <div class="flex gap-4 p-4">
                                    <div class="flex flex-col items-center text-secondary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="3.5em" height="3.5em"
                                            viewBox="0 0 48 48">
                                            <g fill="none" stroke="currentColor" stroke-linecap="round"
                                                stroke-linejoin="round" stroke-width="4">
                                                <path d="M42 20v19a3 3 0 0 1-3 3H9a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3h21">
                                                </path>
                                                <path d="m16 20l10 8L41 7"></path>
                                            </g>
                                        </svg>
                                        <h2 class="text-lg font-bold mt-2">Convenience</h2>
                                    </div>
                                    <p class="text-primary text-justify">
                                        Manage your savings effortlessly with our user-friendly platform.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <ul class="list-disc pl-5">
                            <h1 class="saving-title">Saving type and performance</h1>
                            <li>Standard Savings, Interest Savings, Time Limit Savings, as defined in the
                                Cooperative's Articles of
                                Association Interest Free Savings, Child Savings and Home Savings, Transport Car
                                Savings,
                                Automobile
                                Car
                            </li>
                        </ul>

                        <ul class="list-disc pl-5">
                            <h1 class="saving-title">Regular savings</h1>
                            <li>A member must save a minimum regular savings amount of 750.00;</li>
                            <li>Standard savings rate is based on the member's saving capacity and is based on the
                                member's
                                application
                                It
                                must be approved by the cooperative.</li>
                            <li> Interest for the member's regular savings as determined by the cooperative's bylaws
                                gets,
                            </li>
                        </ul>


                        <ul class="list-disc pl-5">
                            <h1 class="saving-title">Demand savings</h1>
                            <li>The amount of demand savings will be determined according to the user's capacity and
                                needs, accordingly
                                By opening a savings account starting from 500.00 Birr, saving from 100.00 Birr after
                                the
                                account is
                                opened.</li>
                            <li>Interest for the member's savings as determined by the cooperative's bylaws It may be
                                thought,
                                Demand savings can be spent by the member at any time;</li>
                            <li>Demand savings member can provide loan guarantee;</li>
                            <li>The member may spend interest savings only if the funds are not held as collateral;</li>
                        </ul>

                        <ul class="list-disc pl-5">
                            <h1 class="saving-title"> Time limit saving</h1>
                            <li>The minimum amount of time limit deposit will be 50 000.00/fifty thousand.</li>
                            <li>The minimum deposit period is six months.</li>
                            <li>The minimum amount of time limit deposit is 50 000.00/ fifty thousand Birr.</li>
                            <li>The deposit period is six months and the interest rate for six months is 8-12 per month
                                The
                                amount
                                and
                                duration
                                will depend.
                                The deposit amount is more than five hundred thousand birr If it is kept for more than
                                two
                                years,
                                the interest rate is agreed upon by the management committee It will be determined but
                                should
                                not
                                exceed
                                13.5
                                percent. </li>
                            <li>According to the agreement that the cooperative makes with its members as necessary, for
                                a
                                certain
                                period
                                Time
                                may accrue a non-payable time limit savings to the depositor;</li>
                            <li> Reserve the member's time limit savings for loan guarantee in the cooperative can
                            </li>
                            <li>The cooperative can encourage time saving It will be only when it is confirmed that the
                                capacity
                                to
                                use it is high.</li>
                            <li> Time limit savings for loan guarantee until the guarantee is lifted as a cost to the
                                member
                                not
                                paid
                            </li>
                        </ul>

                        <ul class="list-disc pl-5">
                            <h1 class="saving-title">Interest free savings</h1>
                            <li>The cooperative is based on the member's desire and the agreement of the cooperative
                                Savings that are not
                                considered based on interest and savings for different reasons.</li>
                            <li>The right of the savings member to claim interest in any case He will not have it, but
                                if he
                                requests to be considered for interest in the application, the interest will be granted
                                will
                                benefit
                            </li>
                            <li>Interest-free savings can be used as loan collateral;</li>
                            <li>The member can spend the savings without considering the interest, the money as a
                                guarantee
                                Only
                                if
                                not caught.</li>
                        </ul>

                        <ul class="list-disc pl-5">

                            <h1 class="saving-title">Children savings</h1>
                            <li>The children of the members of the cooperative who are under 18 years of age Children
                                you
                                manage
                                can save children.</li>
                            <li>When children start saving, they do not pay registration or lottery fees.</li>
                            <li>The importance of having children's savings so that they have an understanding of the
                                cooperative
                                and It helps them develop a culture of saving.</li>
                            <li>The account will be opened starting with the savings amount of Birr 500.00,</li>
                            <li>Children who have been saving in the cooperative and reached the age of 18 If you meet
                                the
                                other
                                requirements for registration fee, you can become a member by purchasing a lot at the
                                association.
                            </li>
                            <li>Children will earn interest on their savings, but the savings interest will be added to
                                the
                                savings.</li>
                            <li>Children's savings are used as a loan guarantee for the parents or guardians;</li>
                            <li>Children's savings account is an account that can be opened together with parents to
                                spend
                                whenever
                                they want You can open and save a math title where you can.</li>
                        </ul>

                        <ul class="list-disc pl-5">
                            <h1 class="saving-title">Savings of women</h1>
                            <li>In order to encourage women to become entrepreneurs, it has become necessary to initiate
                                a
                                form
                                of
                                savings.</li>
                            <li>The importance of having women's savings so that they have an understanding of the
                                cooperative
                                and
                                It helps them develop a culture of saving.</li>
                            <li>The account is opened starting with the savings amount of Birr 1000.00,</li>
                            <li>Women will get interest on their savings but the interest on savings will be added to
                                the
                                savings.
                            </li>
                            <li>Women's savings are used as loan collateral;</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
useHead({
  title: 'Training - Etcare SACCOs Ltd',
});

</script>

<style>
.saving-p-m {
    padding: 0 4rem 6rem 4rem;
    display: flex;
}

.saving-left {
    width: 60%;
}

.saving-right {
    width: 40%;
}

.saving-right-box {
    box-shadow: 2px 2px 5px theme('colors.secondary');
    border-radius: 0.5rem;
    position: sticky;
    top: 0;
}

.saving-title {
    color: theme('colors.secondary');
    font-family: oswald, sans-serif;
    font-size: 1.5rem;
    font-weight: bold;
    padding: 1rem 0;
}

.saving-left ul li {
    color: theme('colors.primary');
    font-family: robot, sans-serif;
    padding: 5px;
}
</style>